import numpy as np

def relu_function(x):
    return (np.maximum(0,x))

def relu_derivation(x):
    return 0 if x < 0 else 1


class Layer(object):
    """Implements a perceptron network"""
    def __init__(self,input_units):
        self.W = np.array(np.random.randn(input_units)) #constructs a weight matrix with random values
        self.b = np.zeros((1)) #constructs a bias with value zero
        self.input_units=input_units
        self.layer_input = None
        self.layer_preact = None
        self.layer_act = None
        self.learning_rate = 0.001 #sets the learning rate 



    def forward_step(self, inputs):
        """
        Single Layer Forward Propagation
        """
        self.inputs = inputs
        self.output = relu_function(np.sum(np.dot(self.W, inputs))+self.b)  #apply the relu_function to each of the unit's parameters
        return self.output



    def backward_step(self, delta):
        """
        Update all weights and bias with the one delta multiplied by the matching input/activation multiplied with the learning rate (alpha).
        :parameter delta is the value of the delta-rule
        """

        #Calculating the gradient and then updating the parameters
        self.W -= self.learning_rate * delta * self.inputs 
        self.b -= self.learning_rate * delta 
        
        
      

        
       








        
    

       